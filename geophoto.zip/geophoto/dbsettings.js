'use strict';

var connection = {
    host: 'localhost',
    port: 5003,
    user: 'admin',
    password: 'admin'
};

module.exports.connection = connection;
